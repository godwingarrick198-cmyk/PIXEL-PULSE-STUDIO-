class EmptyProvider:
    name="empty"
    async def discover_prospects(self, query):
        return []

OSMProvider=WebDiscoveryProvider=ProductHuntProvider=EmptyProvider
